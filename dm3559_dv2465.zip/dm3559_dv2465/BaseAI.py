class BaseAI():
    
    def getMove(self, grid):
        pass

    def getTrap(self, grid):
        pass
    def getPosition(self):
        pass
    def setPosition(self, new_position):
        pass